from django.db import models
from django.contrib.auth.models import AbstractUser
from imagekit.models import ProcessedImageField
from imagekit.processors import ResizeToFill
from django.core.validators import RegexValidator, MinValueValidator, MaxValueValidator


# Create your models here.
class User(AbstractUser):
    # AbstractUser 기본필드: password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined
    # 전화 번호
    phone = models.CharField(
        validators = [RegexValidator(regex = r'^01([0|1|6|7|8|9]?)-?([0-9]{3,4})-?([0-9]{4})$')],
        max_length = 11,
        unique = True
    )
    
    # # 나이
    # age = models.IntegerField(
    #     default=0,
    #     validators=[MinValueValidator(0)]
    # )

    # # 자산
    # property = models.IntegerField(
    #     default=0,
    #     validators=[MinValueValidator(0)]
    # )
    
    # # 결혼 여부
    # marital_status = models.BooleanField(
    #     default=False
    # )
    
    # # 프로필 이미지
    # profile_img = ProcessedImageField(
    #     blank=True,
    #     upload_to='profile_img/%Y/%m',
    #     processors=[ResizeToFill(300, 300)],
    #     format='JPEG',
    #     options={'quality': 70},
    # )

    # 찜 목록
    # custom_page (list)
    # 가입한 예금 리스트
    # 가입한 적금 리스트
    def __str__(self):
        return self.username
